package WarungMadura;

public class cTransaksi2 {
    //fields
    private cBarang barang[];
    private cPembeli pembeli;
    private int idTransaksi, jumlah[], idx;
    private double totalHarga[],gTotal;
    //constructor
    cTransaksi2() {
    }

    public void tambahTransaksi(int i, cBarang b, cPembeli p, int j) {
        idTransaksi = i;
        barang[idx] = b;
        pembeli = p;
        jumlah[idx] = j;
        totalHarga[idx] = barang[idx].getHargaBarang() * jumlah[idx];
        gTotal += totalHarga[idx];
        idx++;
    }

    public void tampilTransaksi() {
        System.out.println("Data Transaksi");
        System.out.println("ID Transaksi: " + idTransaksi);
        System.out.println("Nama Pembeli: " + pembeli.getNama());
        System.out.println("Daftar Belanja");
        for (int i = 0; i < idx; i++) {
            System.out.print((i+1)+". Nama Barang: " + barang[i].getNamaBarang());
            System.out.print("\tHarga Barang: " + barang[i].getHargaBarang());
            System.out.print("\tJumlah: " + jumlah[i]);
            System.out.print("\tTotal Harga: " + totalHarga[i]);
        }
        System.out.println("Grand Total: " + gTotal);
    }
}


