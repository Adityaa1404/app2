package freshflowerfinal;

public class Transaksi {
    private int idTransaksi;
    private Customer customer;
    private Bucket[] bucket;
    private int[] jumlah;
    private double[] totalHarga;
    private int idx;
    private double totalBayar;
    private boolean sudahDibayar;

    public Transaksi(int idTransaksi, Customer customer, int kapasitas) {
        this.idTransaksi = idTransaksi;
        this.customer = customer;
        this.bucket = new Bucket[kapasitas];
        this.jumlah = new int[kapasitas];
        this.totalHarga = new double[kapasitas];
        this.idx = 0;
        this.totalBayar = 0;
        this.sudahDibayar = false;
    }

    public int getIdTransaksi() {
        return idTransaksi;
    }

    public Customer getCustomer() {
        return customer;
    }

    public double getTotalBayar() {
        return totalBayar;
    }

    public boolean isSudahDibayar() {
        return sudahDibayar;
    }

    public int getIdx() {
        return idx;
    }

    public boolean tambahKeKeranjang(Bucket b, int jumlahBeli) {
        if (idx >= bucket.length) {
            System.out.println("Keranjang penuh.");
            return false;
        }

        bucket[idx] = b;
        jumlah[idx] = jumlahBeli;
        totalHarga[idx] = b.getHarga() * jumlahBeli;
        totalBayar += totalHarga[idx];
        idx++;
        return true;
    }

    public void lihatKeranjang() {
        if (idx == 0) {
            System.out.println("Keranjang kosong.");
            return;
        }

        System.out.println("== Keranjang ==");
        for (int i = 0; i < idx; i++) {
            System.out.println((i + 1) + ". Nama Barang: " + bucket[i].getNama());
            System.out.println("   Harga Barang: " + bucket[i].getHarga());
            System.out.println("   Jumlah: " + jumlah[i]);
            System.out.println("   Total Harga: " + totalHarga[i]);
        }
        System.out.println("Total Bayar: " + totalBayar);
    }

    public boolean bayar(double uangBayar) {
        if (uangBayar >= totalBayar) {
            sudahDibayar = true;
            System.out.println("Pembayaran berhasil. Kembalian: Rp" + (uangBayar - totalBayar));
            return true;
        }

        System.out.println("Uang kurang!");
        return false;
    }

    public void kurangiStok() {
        for (int i = 0; i < idx; i++) {
            bucket[i].setStok(bucket[i].getStok() - jumlah[i]);
        }
    }

    public void cetakRingkasan() {
        System.out.println("ID Transaksi: " + idTransaksi);
        System.out.println("Customer: " + customer.getNama());
        System.out.println("Total Bayar: " + totalBayar);
        System.out.println("Status: " + (sudahDibayar ? "Lunas" : "Belum Dibayar"));
    }

    public void strukTransaksi() {
        System.out.println("=== STRUK TRANSAKSI ===");
        System.out.println("ID Transaksi: " + idTransaksi);
        System.out.println("ID Customer: " + customer.getIdCustomer());
        System.out.println("Nama Customer: " + customer.getNama());
        lihatKeranjang();
    }
}