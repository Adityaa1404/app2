package freshflowerfinal;

public class Customer {
    private String idCustomer;
    private String nama;
    private String alamat;
    private String nomorTelepon;

    public Customer() {
        System.out.println("Data Customer dibuat");
    }

    public Customer(String idCustomer, String nama, String alamat, String nomorTelepon) {
        this.idCustomer = idCustomer;
        this.nama = nama;
        this.alamat = alamat;
        this.nomorTelepon = nomorTelepon;
    }

    public String getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(String idCustomer) {
        this.idCustomer = idCustomer;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getNomorTelepon() {
        return nomorTelepon;
    }

    public void setNomorTelepon(String nomorTelepon) {
        this.nomorTelepon = nomorTelepon;
    }

    public String toString() {
        return "ID Customer: " + idCustomer + " Nama Customer: " + nama + " Alamat: " + alamat + " Nomor Telepon: " + nomorTelepon;
    }
}