
        package freshflowerfinal;

        import java.util.Scanner;

        public class Main {
            public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);

                Bucket[] bucket = new Bucket[99];
                Customer[] customer = new Customer[99];
                Transaksi[] daftarTransaksi = new Transaksi[99];

                Admin admin = new Admin();
                Owner owner = new Owner();

                int[] jumlahBucket = new int[] { 6 };
                int[] jumlahCustomer = new int[] { 1 };
                int[] jumlahTransaksi = new int[] { 0 };
                int[] idTransaksi = new int[] { 1 };
                Transaksi[] transaksiAktif = new Transaksi[1];

                isiDataAwal(bucket, customer);

                int pilihMenu;
                do {
                    System.out.println("Aplikasi Fresh Flower");
                    System.out.println("1. Admin");
                    System.out.println("2. Owner");
                    System.out.println("3. Keluar");
                    pilihMenu = bacaInt(scanner, "Pilih menu: ");

                    switch (pilihMenu) {
                        case 1:
                            if (loginAdmin(scanner, admin)) {
                                menuAdmin(scanner, bucket, customer, daftarTransaksi, transaksiAktif, jumlahBucket, jumlahCustomer, jumlahTransaksi, idTransaksi);
                            }
                            break;
                        case 2:
                            if (loginOwner(scanner, owner)) {
                                menuOwner(scanner, bucket, customer, daftarTransaksi, jumlahBucket, jumlahCustomer, jumlahTransaksi);
                            }
                            break;
                        case 3:
                            System.out.println("Keluar");
                            break;
                        default:
                            System.out.println("Pilihan tidak valid");
                            break;
                    }
                } while (pilihMenu != 3);

                scanner.close();
            }

            private static void isiDataAwal(Bucket[] bucket, Customer[] customer) {
                bucket[0] = new Bunga(10000, 10, "Mawar");
                bucket[1] = new Boneka(50000, 5, "Hello Kitty");
                bucket[2] = new Jajan(20000, 20, "Coklat");
                bucket[3] = new Bunga(15000, 15, "Tulip");
                bucket[4] = new Boneka(75000, 3, "Doraemon");
                bucket[5] = new Jajan(30000, 10, "Pocky");

                customer[0] = new Customer("CUS001", "Cici", "Bandung", "08123456789");
            }

            private static boolean loginAdmin(Scanner scanner, Admin admin) {
                String username;
                String password;
                do {
                    System.out.print("Masukkan username admin: ");
                    username = scanner.nextLine();
                    System.out.print("Password: ");
                    password = scanner.nextLine();

                    if (admin.login(username, password)) {
                        System.out.println("Login berhasil!");
                        return true;
                    }
                    System.out.println("Login gagal!");
                    System.out.print("Coba lagi? (Y/N): ");
                    String ulang = scanner.nextLine();
                    if (!ulang.equalsIgnoreCase("Y")) {
                        return false;
                    }
                } while (true);
            }

            private static boolean loginOwner(Scanner scanner, Owner owner) {
                String nama;
                String password;
                do {
                    System.out.print("Masukkan nama owner: ");
                    nama = scanner.nextLine();
                    System.out.print("Password: ");
                    password = scanner.nextLine();

                    if (owner.login(nama, password)) {
                        System.out.println("Login berhasil!");
                        return true;
                    }
                    System.out.println("Login gagal!");
                    System.out.print("Coba lagi? (Y/N): ");
                    String ulang = scanner.nextLine();
                    if (!ulang.equalsIgnoreCase("Y")) {
                        return false;
                    }
                } while (true);
            }

            private static void menuAdmin(Scanner scanner, Bucket[] bucket, Customer[] customer, Transaksi[] daftarTransaksi,
                    Transaksi[] transaksiAktif, int[] jumlahBucket, int[] jumlahCustomer, int[] jumlahTransaksi, int[] idTransaksi) {
                int pilihMenuAdmin;
                do {
                    System.out.println("== Menu Admin ==");
                    System.out.println("1. Tambah Keranjang");
                    System.out.println("2. Lihat Keranjang");
                    System.out.println("3. Hapus Keranjang");
                    System.out.println("4. Bayar Transaksi");
                    System.out.println("5. Kembali ke Menu Utama");
                    pilihMenuAdmin = bacaInt(scanner, "Pilih menu: ");

                    switch (pilihMenuAdmin) {
                        case 1:
                            tambahKeKeranjang(scanner, bucket, customer, jumlahBucket[0], jumlahCustomer, transaksiAktif, idTransaksi);
                            break;
                        case 2:
                            if (transaksiAktif[0] == null) {
                                System.out.println("Keranjang kosong.");
                            } else {
                                transaksiAktif[0].lihatKeranjang();
                            }
                            break;
                        case 3:
                            transaksiAktif[0] = null;
                            System.out.println("Keranjang berhasil dihapus.");
                            break;
                        case 4:
                            if (transaksiAktif[0] == null) {
                                System.out.println("Keranjang kosong.");
                                break;
                            }
                            transaksiAktif[0].lihatKeranjang();
                            double bayar = bacaDouble(scanner, "Masukkan uang bayar: Rp");
                            if (transaksiAktif[0].bayar(bayar)) {
                                transaksiAktif[0].kurangiStok();
                                daftarTransaksi[jumlahTransaksi[0]] = transaksiAktif[0];
                                jumlahTransaksi[0]++;
                                transaksiAktif[0].strukTransaksi();
                                transaksiAktif[0] = null;
                                idTransaksi[0]++;
                            }
                            break;
                        case 5:
                            break;
                        default:
                            System.out.println("Pilihan tidak valid");
                            break;
                    }
                } while (pilihMenuAdmin != 5);
            }

            private static void menuOwner(Scanner scanner, Bucket[] bucket, Customer[] customer, Transaksi[] daftarTransaksi,
                    int[] jumlahBucket, int[] jumlahCustomer, int[] jumlahTransaksi) {
                int pilihMenuOwner;
                do {
                    System.out.println("== Menu Owner ==");
                    System.out.println("1. Data Bucket");
                    System.out.println("2. Data Transaksi");
                    System.out.println("3. Data Customer");
                    System.out.println("4. Kembali ke Menu Utama");
                    pilihMenuOwner = bacaInt(scanner, "Pilih menu: ");

                    switch (pilihMenuOwner) {
                        case 1:
                            menuDataBucket(scanner, bucket, jumlahBucket);
                            break;
                        case 2:
                            menuDataTransaksi(scanner, daftarTransaksi, jumlahTransaksi[0]);
                            break;
                        case 3:
                            menuDataCustomer(scanner, customer, jumlahCustomer);
                            break;
                        case 4:
                            break;
                        default:
                            System.out.println("Pilihan tidak valid, silakan coba lagi.");
                            break;
                    }
                } while (pilihMenuOwner != 4);
            }

            private static void tambahKeKeranjang(Scanner scanner, Bucket[] bucket, Customer[] customer, int jumlahBucket,
                    int[] jumlahCustomer, Transaksi[] transaksiAktif, int[] idTransaksi) {
                if (jumlahBucket == 0) {
                    System.out.println("Data bucket kosong.");
                    return;
                }

                if (transaksiAktif[0] == null) {
                    System.out.println("Pilih customer");
                    Customer pembeli = pilihAtauBuatCustomer(scanner, customer, jumlahCustomer);
                    if (pembeli == null) {
                        return;
                    }
                    transaksiAktif[0] = new Transaksi(idTransaksi[0], pembeli, 99);
                }

                lihatDataBucket(bucket, jumlahBucket);
                int nomorBucket = bacaInt(scanner, "Masukkan nomor bucket yang ingin ditambahkan ke keranjang: ");
                if (nomorBucket < 1 || nomorBucket > jumlahBucket || bucket[nomorBucket - 1] == null) {
                    System.out.println("Bucket tidak ditemukan.");
                    return;
                }

                int jumlahItem = bacaInt(scanner, "Masukkan jumlah: ");
                if (jumlahItem <= 0) {
                    System.out.println("Jumlah tidak valid.");
                    return;
                }

                if (jumlahItem > bucket[nomorBucket - 1].getStok()) {
                    System.out.println("Stok tidak cukup.");
                    return;
                }

                transaksiAktif[0].tambahKeKeranjang(bucket[nomorBucket - 1], jumlahItem);
                System.out.println("Produk berhasil ditambahkan ke keranjang.");
            }

            private static Customer pilihAtauBuatCustomer(Scanner scanner, Customer[] customer, int[] jumlahCustomer) {
                int pilih;
                do {
                    System.out.println("1. Pilih customer yang sudah ada");
                    System.out.println("2. Tambah customer baru");
                    pilih = bacaInt(scanner, "Pilih menu: ");

                    switch (pilih) {
                        case 1:
                            if (jumlahCustomer[0] == 0) {
                                System.out.println("Belum ada customer.");
                                break;
                            }
                            lihatDataCustomer(customer, jumlahCustomer[0]);
                            int index = bacaInt(scanner, "Pilih nomor customer: ");
                            if (index < 1 || index > jumlahCustomer[0] || customer[index - 1] == null) {
                                System.out.println("Customer tidak ditemukan.");
                                return null;
                            }
                            return customer[index - 1];
                        case 2:
                            return tambahCustomerBaru(scanner, customer, jumlahCustomer);
                        default:
                            System.out.println("Pilihan tidak valid.");
                            break;
                    }
                } while (true);
            }

            private static Customer tambahCustomerBaru(Scanner scanner, Customer[] customer, int[] jumlahCustomer) {
                if (jumlahCustomer[0] >= customer.length) {
                    System.out.println("Data customer penuh.");
                    return null;
                }

                String idCustomer = "CUS" + String.format("%03d", jumlahCustomer[0] + 1);
                System.out.print("Nama customer: ");
                String nama = scanner.nextLine();
                System.out.print("Alamat customer: ");
                String alamat = scanner.nextLine();
                System.out.print("Nomor telepon: ");
                String nomorTelepon = scanner.nextLine();

                customer[jumlahCustomer[0]] = new Customer(idCustomer, nama, alamat, nomorTelepon);
                jumlahCustomer[0]++;
                System.out.println("Customer berhasil ditambahkan.");
                return customer[jumlahCustomer[0] - 1];
            }

            private static void menuDataBucket(Scanner scanner, Bucket[] bucket, int[] jumlahBucket) {
                int pilihMenuBucket;
                do {
                    System.out.println("== Data Bucket ==");
                    System.out.println("1. Lihat Data Bucket");
                    System.out.println("2. Tambah Data Bucket");
                    System.out.println("3. Ubah Data Bucket");
                    System.out.println("4. Hapus Data Bucket");
                    System.out.println("5. Kembali ke Menu Owner");
                    pilihMenuBucket = bacaInt(scanner, "Pilih menu: ");

                    switch (pilihMenuBucket) {
                        case 1:
                            lihatDataBucket(bucket, jumlahBucket[0]);
                            break;
                        case 2:
                            tambahDataBucket(scanner, bucket, jumlahBucket);
                            break;
                        case 3:
                            ubahDataBucket(scanner, bucket, jumlahBucket[0]);
                            break;
                        case 4:
                            hapusDataBucket(scanner, bucket, jumlahBucket);
                            break;
                        case 5:
                            break;
                        default:
                            System.out.println("Pilihan tidak valid, silakan coba lagi.");
                            break;
                    }
                } while (pilihMenuBucket != 5);
            }

            private static void tambahDataBucket(Scanner scanner, Bucket[] bucket, int[] jumlahBucket) {
                if (jumlahBucket[0] >= bucket.length) {
                    System.out.println("Data bucket penuh.");
                    return;
                }

                System.out.print("Masukkan nama bucket: ");
                String namaBucket = scanner.nextLine();
                double hargaBucket = bacaDouble(scanner, "Masukkan harga bucket: ");
                int stokBucket = bacaInt(scanner, "Masukkan stok bucket: ");
                System.out.print("Masukkan jenis bucket (Bunga/Boneka/Jajan): ");
                String jenisBucket = scanner.nextLine();

                Bucket dataBaru = buatBucketBaru(jenisBucket, hargaBucket, stokBucket, namaBucket);
                if (dataBaru == null) {
                    System.out.println("Jenis bucket tidak valid.");
                    return;
                }

                bucket[jumlahBucket[0]] = dataBaru;
                jumlahBucket[0]++;
                System.out.println("Bucket berhasil ditambahkan.");
            }

            private static void ubahDataBucket(Scanner scanner, Bucket[] bucket, int jumlahBucket) {
                if (jumlahBucket == 0) {
                    System.out.println("Data bucket kosong.");
                    return;
                }

                lihatDataBucket(bucket, jumlahBucket);
                int nomorBucket = bacaInt(scanner, "Masukkan nomor bucket yang ingin diubah: ");
                if (nomorBucket < 1 || nomorBucket > jumlahBucket || bucket[nomorBucket - 1] == null) {
                    System.out.println("Bucket tidak ditemukan.");
                    return;
                }

                int menuUbahBucket;
                do {
                    System.out.println("Pilih jenis perubahan:");
                    System.out.println("1. Nama");
                    System.out.println("2. Harga");
                    System.out.println("3. Stok");
                    System.out.println("4. Kembali ke Menu Data Bucket");
                    menuUbahBucket = bacaInt(scanner, "Masukkan pilihan: ");

                    switch (menuUbahBucket) {
                        case 1:
                            System.out.print("Masukkan nama baru: ");
                            String namaBaru = scanner.nextLine();
                            bucket[nomorBucket - 1].setNama(namaBaru);
                            System.out.println("Nama berhasil diubah.");
                            break;
                        case 2:
                            bucket[nomorBucket - 1].setHarga(bacaDouble(scanner, "Masukkan harga baru: "));
                            System.out.println("Harga berhasil diubah.");
                            break;
                        case 3:
                            bucket[nomorBucket - 1].setStok(bacaInt(scanner, "Masukkan stok baru: "));
                            System.out.println("Stok berhasil diubah.");
                            break;
                        case 4:
                            break;
                        default:
                            System.out.println("Pilihan tidak valid.");
                            break;
                    }
                } while (menuUbahBucket != 4);
            }

            private static void hapusDataBucket(Scanner scanner, Bucket[] bucket, int[] jumlahBucket) {
                if (jumlahBucket[0] == 0) {
                    System.out.println("Data bucket kosong.");
                    return;
                }

                lihatDataBucket(bucket, jumlahBucket[0]);
                int nomorBucket = bacaInt(scanner, "Masukkan nomor bucket yang ingin dihapus: ");
                if (nomorBucket < 1 || nomorBucket > jumlahBucket[0] || bucket[nomorBucket - 1] == null) {
                    System.out.println("Bucket tidak ditemukan.");
                    return;
                }

                for (int i = nomorBucket - 1; i < jumlahBucket[0] - 1; i++) {
                    bucket[i] = bucket[i + 1];
                }
                bucket[jumlahBucket[0] - 1] = null;
                jumlahBucket[0]--;
                System.out.println("Bucket berhasil dihapus.");
            }

            private static void menuDataTransaksi(Scanner scanner, Transaksi[] transaksi, int jumlahTransaksi) {
                int pilihMenuTransaksi;
                do {
                    System.out.println("== Data Transaksi ==");
                    System.out.println("1. Lihat Semua Transaksi");
                    System.out.println("2. Lihat Detail Transaksi");
                    System.out.println("3. Kembali ke Menu Owner");
                    pilihMenuTransaksi = bacaInt(scanner, "Pilih menu: ");

                    switch (pilihMenuTransaksi) {
                        case 1:
                            lihatSemuaTransaksi(transaksi, jumlahTransaksi);
                            break;
                        case 2:
                            int idCari = bacaInt(scanner, "Masukkan ID transaksi: ");
                            lihatDetailTransaksi(transaksi, jumlahTransaksi, idCari);
                            break;
                        case 3:
                            break;
                        default:
                            System.out.println("Pilihan tidak valid, silakan coba lagi.");
                            break;
                    }
                } while (pilihMenuTransaksi != 3);
            }

            private static void menuDataCustomer(Scanner scanner, Customer[] customer, int[] jumlahCustomer) {
                int pilihMenuCustomer;
                do {
                    System.out.println("== Data Customer ==");
                    System.out.println("1. Lihat Data Customer");
                    System.out.println("2. Tambah Data Customer");
                    System.out.println("3. Ubah Data Customer");
                    System.out.println("4. Hapus Data Customer");
                    System.out.println("5. Kembali ke Menu Owner");
                    pilihMenuCustomer = bacaInt(scanner, "Pilih menu: ");

                    switch (pilihMenuCustomer) {
                        case 1:
                            lihatDataCustomer(customer, jumlahCustomer[0]);
                            break;
                        case 2:
                            tambahCustomerOwner(scanner, customer, jumlahCustomer);
                            break;
                        case 3:
                            ubahDataCustomer(scanner, customer, jumlahCustomer[0]);
                            break;
                        case 4:
                            hapusDataCustomer(scanner, customer, jumlahCustomer);
                            break;
                        case 5:
                            break;
                        default:
                            System.out.println("Pilihan tidak valid, silakan coba lagi.");
                            break;
                    }
                } while (pilihMenuCustomer != 5);
            }

            private static void tambahCustomerOwner(Scanner scanner, Customer[] customer, int[] jumlahCustomer) {
                if (jumlahCustomer[0] >= customer.length) {
                    System.out.println("Data customer penuh.");
                    return;
                }

                String idCustomer = "CUS" + String.format("%03d", jumlahCustomer[0] + 1);
                System.out.print("Nama customer: ");
                String nama = scanner.nextLine();
                System.out.print("Alamat customer: ");
                String alamat = scanner.nextLine();
                System.out.print("Nomor telepon: ");
                String nomorTelepon = scanner.nextLine();

                customer[jumlahCustomer[0]] = new Customer(idCustomer, nama, alamat, nomorTelepon);
                jumlahCustomer[0]++;
                System.out.println("Customer berhasil ditambahkan.");
            }

            private static void ubahDataCustomer(Scanner scanner, Customer[] customer, int jumlahCustomer) {
                if (jumlahCustomer == 0) {
                    System.out.println("Data customer kosong.");
                    return;
                }

                lihatDataCustomer(customer, jumlahCustomer);
                int nomorCustomer = bacaInt(scanner, "Masukkan nomor customer yang ingin diubah: ");
                if (nomorCustomer < 1 || nomorCustomer > jumlahCustomer || customer[nomorCustomer - 1] == null) {
                    System.out.println("Customer tidak ditemukan.");
                    return;
                }

                int menuUbahCustomer;
                do {
                    System.out.println("Pilih jenis perubahan:");
                    System.out.println("1. Nama");
                    System.out.println("2. Alamat");
                    System.out.println("3. Nomor Telepon");
                    System.out.println("4. Kembali ke Menu Data Customer");
                    menuUbahCustomer = bacaInt(scanner, "Masukkan pilihan: ");

                    switch (menuUbahCustomer) {
                        case 1:
                            System.out.print("Masukkan nama baru: ");
                            customer[nomorCustomer - 1].setNama(scanner.nextLine());
                            System.out.println("Nama berhasil diubah.");
                            break;
                        case 2:
                            System.out.print("Masukkan alamat baru: ");
                            customer[nomorCustomer - 1].setAlamat(scanner.nextLine());
                            System.out.println("Alamat berhasil diubah.");
                            break;
                        case 3:
                            System.out.print("Masukkan nomor telepon baru: ");
                            customer[nomorCustomer - 1].setNomorTelepon(scanner.nextLine());
                            System.out.println("Nomor telepon berhasil diubah.");
                            break;
                        case 4:
                            break;
                        default:
                            System.out.println("Pilihan tidak valid.");
                            break;
                    }
                } while (menuUbahCustomer != 4);
            }

            private static void hapusDataCustomer(Scanner scanner, Customer[] customer, int[] jumlahCustomer) {
                if (jumlahCustomer[0] == 0) {
                    System.out.println("Data customer kosong.");
                    return;
                }

                lihatDataCustomer(customer, jumlahCustomer[0]);
                int nomorCustomer = bacaInt(scanner, "Masukkan nomor customer yang ingin dihapus: ");
                if (nomorCustomer < 1 || nomorCustomer > jumlahCustomer[0] || customer[nomorCustomer - 1] == null) {
                    System.out.println("Customer tidak ditemukan.");
                    return;
                }

                for (int i = nomorCustomer - 1; i < jumlahCustomer[0] - 1; i++) {
                    customer[i] = customer[i + 1];
                }
                customer[jumlahCustomer[0] - 1] = null;
                jumlahCustomer[0]--;
                System.out.println("Customer berhasil dihapus.");
            }

            private static Bucket buatBucketBaru(String jenisBucket, double hargaBucket, int stokBucket, String namaBucket) {
                if (jenisBucket.equalsIgnoreCase("Bunga")) {
                    return new Bunga(hargaBucket, stokBucket, namaBucket);
                }
                if (jenisBucket.equalsIgnoreCase("Boneka")) {
                    return new Boneka(hargaBucket, stokBucket, namaBucket);
                }
                if (jenisBucket.equalsIgnoreCase("Jajan")) {
                    return new Jajan(hargaBucket, stokBucket, namaBucket);
                }
                return null;
            }

            public static void lihatDataBucket(Bucket[] bucket, int jumlahBucket) {
                System.out.println("== Daftar Bucket ==");
                if (jumlahBucket == 0) {
                    System.out.println("Data bucket kosong.");
                    return;
                }

                for (int i = 0; i < jumlahBucket; i++) {
                    if (bucket[i] != null) {
                        System.out.println((i + 1) + ". " + bucket[i]);
                    }
                }
            }

            public static void lihatDataCustomer(Customer[] customer, int jumlahCustomer) {
                System.out.println("== Daftar Customer ==");
                if (jumlahCustomer == 0) {
                    System.out.println("Data customer kosong.");
                    return;
                }

                for (int i = 0; i < jumlahCustomer; i++) {
                    if (customer[i] != null) {
                        System.out.println((i + 1) + ". " + customer[i]);
                    }
                }
            }

            public static void lihatSemuaTransaksi(Transaksi[] transaksi, int jumlahTransaksi) {
                System.out.println("== Daftar Transaksi ==");
                if (jumlahTransaksi == 0) {
                    System.out.println("Belum ada transaksi.");
                    return;
                }

                for (int i = 0; i < jumlahTransaksi; i++) {
                    if (transaksi[i] != null) {
                        System.out.println((i + 1) + ". ");
                        transaksi[i].cetakRingkasan();
                    }
                }
            }

            public static void lihatDetailTransaksi(Transaksi[] transaksi, int jumlahTransaksi, int idCari) {
                for (int i = 0; i < jumlahTransaksi; i++) {
                    if (transaksi[i] != null && transaksi[i].getIdTransaksi() == idCari) {
                        transaksi[i].strukTransaksi();
                        return;
                    }
                }
                System.out.println("Transaksi tidak ditemukan.");
            }

            private static String bacaString(Scanner scanner, String prompt) {
                System.out.print(prompt);
                return scanner.nextLine().trim();
            }

            private static int bacaInt(Scanner scanner, String prompt) {
                while (true) {
                    try {
                        System.out.print(prompt);
                        return Integer.parseInt(scanner.nextLine().trim());
                    } catch (NumberFormatException e) {
                        System.out.println("Input harus berupa angka bulat.");
                    }
                }
            }

            private static double bacaDouble(Scanner scanner, String prompt) {
                while (true) {
                    try {
                        System.out.print(prompt);
                        return Double.parseDouble(scanner.nextLine().trim());
                    } catch (NumberFormatException e) {
                        System.out.println("Input harus berupa angka.");
                    }
                }
            }
        }