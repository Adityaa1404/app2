package freshflowerfinal;

public class Bucket {
    // fields
    private double harga;
    private int stok;
    private String nama;

    // constructor
    public Bucket() {
        System.out.println("Data Bucket dibuat");
    }

    // constructor overloading
    public Bucket(double harga, int stok) {
        this.harga = harga;
        this.stok = stok;
    }

    // setter and getter

    public double getHarga() {
        return harga;
    }

    public void setHarga(double harga) {
        this.harga = harga;
    }

    public int getStok() {
        return stok;
    }

    public void setStok(int stok) {
        this.stok = stok;
    }
    public String getNama() {
        return nama;
    }
    public void setNama(String nama) {
        this.nama = nama;
    }
    
    public String toString() {
        return "Nama: " + nama + "\tHarga: " + harga + "\tStok: " + stok +" " ;
    }







    


}
