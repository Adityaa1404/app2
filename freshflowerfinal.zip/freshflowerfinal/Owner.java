package freshflowerfinal;

public class Owner {
    // fields
    private String nama = "Owner";
    private String password = "Owner123";

    // constructor
    public Owner() {}   

    // setter and getter
    public String getNama() {
        return nama;
    }

    public String getPassword() {
        return password;
    }

    // login
    public boolean login(String nama, String password) {
        if (this.nama.equals(nama) && this.password.equals(password)) {
            return true;
        } else {
            return false;
        }
    }

}
